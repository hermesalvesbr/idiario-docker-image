NonStupidDigestAssets.whitelist += %w(
  profile-default.jpg
  favicon.ico
  select2-spinner.gif
  500.html
  422.html
  404.html
  bg.svg
)
