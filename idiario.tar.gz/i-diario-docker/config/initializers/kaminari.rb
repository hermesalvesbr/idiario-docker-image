Kaminari.configure do |config|

  config.window = 1

end
