RouteTranslator.config do |config|
  config.hide_locale = true
  config.generate_unlocalized_routes = false
end
