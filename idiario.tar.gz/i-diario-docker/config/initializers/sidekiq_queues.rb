EXAM_POSTING_QUEUES = (Rails.application.secrets.EXAM_POSTING_QUEUES || 'exam_posting').split(',')
